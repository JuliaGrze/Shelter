﻿using Application.Dtos.Adoptions;
using Application.Dtos.Adoptions.HomeVisit;
using Application.Interfaces;
using Domain.Entities;
using Domain.Enums;
using Infrastructure.Repositories.Abstractions;
using Infrastructure.Repositories.Abstractions.Adoptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Services
{
    public class AdoptionProcessService : IAdoptionProcessService
    {
        private IAdoptionUnitOfWork _adoptUnitOfWork;
        public AdoptionProcessService(IAdoptionUnitOfWork adoptUnitOfWork)
        {
            _adoptUnitOfWork = adoptUnitOfWork;
        }

        // —————————————————————————————————————————————
        // Złożenie wniosku (Client)
        // —————————————————————————————————————————————
        public async Task ApproveAsync(int appId, UpdateAdoptionStatusRequest dto, string reviewerUserId, CancellationToken ct = default)
        {
        }

        public Task<GenerateContractResponse> GenerateContractAsync(int appId, CancellationToken ct = default)
        {
            throw new NotImplementedException();
        }

        public Task RejectAsync(int appId, UpdateAdoptionStatusRequest dto, string reviewerUserId, CancellationToken ct = default)
        {
            throw new NotImplementedException();
        }

        public Task ScheduleHomeVisitAsync(int appId, ScheduleHomeVisitRequest dto, CancellationToken ct = default)
        {
            throw new NotImplementedException();
        }

        public Task SetHomeVisitResultAsync(int appId, SetHomeVisitResultRequest dto, CancellationToken ct = default)
        {
            throw new NotImplementedException();
        }

        public Task SetInReviewAsync(int appId, UpdateAdoptionStatusRequest dto, string reviewerUserId, CancellationToken ct = default)
        {
            throw new NotImplementedException();
        }

        public Task SignContractAsync(int appId, string signerUserId, CancellationToken ct = default)
        {
            throw new NotImplementedException();
        }

        public Task<SubmitApplicationResponse> SubmitAsync(SubmitApplicationRequest dto, string applicantUserId, CancellationToken ct = default)
        {
            throw new NotImplementedException();
        }
    }
}
