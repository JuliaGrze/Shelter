﻿using Domain.Entities;
using Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Dtos.Animal
{
    public class CreateAnimalDto
    {
        public string Name { get; set; } = "";
        public int SpeciesId { get; set; } //Foreign Key


        public DateOnly BirthDate { get; set; } //we calculate age from date of birth
        public Sex Sex { get; set; }
        public AnimalStatus Status { get; set; } //Available, Reserved, Adopted, NotAvailable

        public string Description { get; set; } = "";
        public string PhotoUrl { get; set; } = "";
    }
}
